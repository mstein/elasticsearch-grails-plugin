package org.grails.plugins.elasticsearch.conversion.marshall

public interface Marshaller {
  public Object marshall(property)

  /*public unmarshall()*/
}